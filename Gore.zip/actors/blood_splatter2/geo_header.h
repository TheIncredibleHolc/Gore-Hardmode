extern const GeoLayout blood_splatter2_geo[];
extern Lights1 blood_splatter2_f3dlite_material_001_lights;
extern u8 blood_splatter2_blood_splat2_rgba16[];
extern Vtx blood_splatter2_Plane_mesh_layer_5_vtx_0[4];
extern Gfx blood_splatter2_Plane_mesh_layer_5_tri_0[];
extern Gfx mat_blood_splatter2_f3dlite_material_001[];
extern Gfx mat_revert_blood_splatter2_f3dlite_material_001[];
extern Gfx blood_splatter2_Plane_mesh_layer_5[];
extern Gfx blood_splatter2_material_revert_render_settings[];
