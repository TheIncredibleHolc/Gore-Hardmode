extern void scroll_lava_Plane_mesh_layer_1_vtx_0();
extern void scroll_gfx_mat_lava_f3dlite_material_001();
extern void scroll_actor_geo_lava();
