extern const Collision lava_collision[];
