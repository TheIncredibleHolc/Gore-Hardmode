extern const GeoLayout skybox_geo[];
extern u8 skybox_streaks_rgba16[];
extern Vtx skybox_Cylinder_mesh_layer_5_vtx_0[74];
extern Gfx skybox_Cylinder_mesh_layer_5_tri_0[];
extern Gfx mat_skybox_f3dlite_material[];
extern Gfx mat_revert_skybox_f3dlite_material[];
extern Gfx skybox_Cylinder_mesh_layer_5[];
extern Gfx skybox_material_revert_render_settings[];
