extern const GeoLayout lightning_geo[];
extern u8 lightning__01_rgba16[];
extern Vtx lightning_Plane_mesh_layer_5_vtx_0[4];
extern Gfx lightning_Plane_mesh_layer_5_tri_0[];
extern Gfx mat_lightning_f3dlite_material[];
extern Gfx mat_revert_lightning_f3dlite_material[];
extern Gfx lightning_Plane_mesh_layer_5[];
extern Gfx lightning_material_revert_render_settings[];
