extern const Collision platform_collision[];
