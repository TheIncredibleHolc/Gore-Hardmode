extern const Collision gsshadowcol_collision[];
