extern const GeoLayout gsshadow_geo[];
extern Lights1 gsshadow_f3dlite_material_lights;
extern u8 gsshadow_grand_star_energy_floor_rgba16[];
extern Vtx gsshadow_Plane_mesh_layer_5_vtx_0[4];
extern Gfx gsshadow_Plane_mesh_layer_5_tri_0[];
extern Gfx mat_gsshadow_f3dlite_material[];
extern Gfx mat_revert_gsshadow_f3dlite_material[];
extern Gfx gsshadow_Plane_mesh_layer_5[];
extern Gfx gsshadow_material_revert_render_settings[];
