// 0x16000E84
const GeoLayout smiler_geo[] = {
   GEO_SHADOW(SHADOW_CIRCLE_4_VERTS, 0x00, 00),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_ALPHA, smiler_seg3_dl_0302A660),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
