extern const GeoLayout lightning2_geo[];
extern u8 lightning2__02_rgba16[];
extern Vtx lightning2_Plane_mesh_layer_5_vtx_0[4];
extern Gfx lightning2_Plane_mesh_layer_5_tri_0[];
extern Gfx mat_lightning2_f3dlite_material[];
extern Gfx mat_revert_lightning2_f3dlite_material[];
extern Gfx lightning2_Plane_mesh_layer_5[];
extern Gfx lightning2_material_revert_render_settings[];
