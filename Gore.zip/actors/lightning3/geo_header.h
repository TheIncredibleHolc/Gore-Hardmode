extern const GeoLayout lightning3_geo[];
extern u8 lightning3__03_rgba16[];
extern Vtx lightning3_Plane_mesh_layer_5_vtx_0[4];
extern Gfx lightning3_Plane_mesh_layer_5_tri_0[];
extern Gfx mat_lightning3_f3dlite_material[];
extern Gfx mat_revert_lightning3_f3dlite_material[];
extern Gfx lightning3_Plane_mesh_layer_5[];
extern Gfx lightning3_material_revert_render_settings[];
