extern const GeoLayout skybox2_geo[];
extern u8 skybox2_lightning_rgba16[];
extern Vtx skybox2_Cylinder_mesh_layer_5_vtx_0[80];
extern Gfx skybox2_Cylinder_mesh_layer_5_tri_0[];
extern Gfx mat_skybox2_f3dlite_material[];
extern Gfx mat_revert_skybox2_f3dlite_material[];
extern Gfx skybox2_Cylinder_mesh_layer_5[];
extern Gfx skybox2_material_revert_render_settings[];
